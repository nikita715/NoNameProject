create trigger ORDERS_T
	before insert
	on ORDERS
	for each row
DECLARE
BEGIN 
    SELECT ID_ORDERS.NEXTVAL INTO :NEW.ID FROM DUAL; 
END ORDERS_T;