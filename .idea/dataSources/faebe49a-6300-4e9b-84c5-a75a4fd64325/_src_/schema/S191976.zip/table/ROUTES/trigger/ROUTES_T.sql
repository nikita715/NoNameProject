create trigger ROUTES_T
	before insert
	on ROUTES
	for each row
DECLARE
BEGIN 
    SELECT ID_ROUTES.NEXTVAL INTO :NEW.ID FROM DUAL; 
END ROUTES_T;