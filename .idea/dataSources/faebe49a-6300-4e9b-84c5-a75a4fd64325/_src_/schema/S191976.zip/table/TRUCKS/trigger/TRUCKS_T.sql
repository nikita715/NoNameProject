create trigger TRUCKS_T
	before insert
	on TRUCKS
	for each row
DECLARE
BEGIN 
    SELECT ID_TRUCKS.NEXTVAL INTO :NEW.ID FROM DUAL; 
END TRUCKS_T;